import { Item } from './../../shared/item.model';
import { ItemService } from './../../shared/item.service';
import { OrderItem } from './../../shared/order-item.model';
import { Component, OnInit, Inject } from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material";

@Component({
  selector: 'app-order-items',
  templateUrl: './order-items.component.html',
  styleUrls: ['./order-items.component.scss']
})
export class OrderItemsComponent implements OnInit {
  formData:OrderItem;
  itemList: Item[];

  constructor(
    @Inject (MAT_DIALOG_DATA) public data,
    public dialogRef:MatDialogRef<OrderItemsComponent>,
    private itemService:ItemService
    ){
  }

  ngOnInit() {

    this.itemService.getItemList().then(res => this.itemList = res as Item[]);

    this.formData={
      orderItemId:null,
      oderId:this.data.orderId,
      itemId:0,
      quantity:0,
      itemName:'',
      price:0,
      total:0
    }
  }

  updatePrice(ctrl){
    if(ctrl.selectedIndex == 0){
      this.formData.price =0;
    }
  }
}
