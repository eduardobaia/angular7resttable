export class Customer {

  customerId :number;
  name :string;


}
