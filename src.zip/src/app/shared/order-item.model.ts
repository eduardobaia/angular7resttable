export class OrderItem {
  orderItemId: number;
  oderId: number;
  itemId:number;
  quantity:number;
  itemName: string;
  price:number;
  total: number;
}
