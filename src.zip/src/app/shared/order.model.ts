export class Order {
  orderId: number;
  orderNo: string;
  customerId: number;
  pMethod: string;
  gTotal: number;
}
