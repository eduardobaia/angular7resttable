export class Item {
  itemId: number;
  name :string;
  price: number;
}
